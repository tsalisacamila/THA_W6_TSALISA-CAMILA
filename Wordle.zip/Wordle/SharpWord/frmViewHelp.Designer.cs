﻿namespace SharpWord
{
    partial class frmViewHelp 
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmViewHelp));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl15 = new System.Windows.Forms.Label();
            this.lbl14 = new System.Windows.Forms.Label();
            this.lbl13 = new System.Windows.Forms.Label();
            this.lbl12 = new System.Windows.Forms.Label();
            this.lbl11 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbl25 = new System.Windows.Forms.Label();
            this.lbl24 = new System.Windows.Forms.Label();
            this.lbl23 = new System.Windows.Forms.Label();
            this.lbl22 = new System.Windows.Forms.Label();
            this.lbl21 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lbl35 = new System.Windows.Forms.Label();
            this.lbl34 = new System.Windows.Forms.Label();
            this.lbl33 = new System.Windows.Forms.Label();
            this.lbl32 = new System.Windows.Forms.Label();
            this.lbl31 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(21, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(517, 137);
            this.label1.TabIndex = 0;
            this.label1.Text = resources.GetString("label1.Text");
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Location = new System.Drawing.Point(25, 171);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(513, 2);
            this.label2.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(13, 190);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 30);
            this.label3.TabIndex = 2;
            this.label3.Text = "Examples";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lbl15);
            this.panel1.Controls.Add(this.lbl14);
            this.panel1.Controls.Add(this.lbl13);
            this.panel1.Controls.Add(this.lbl12);
            this.panel1.Controls.Add(this.lbl11);
            this.panel1.Location = new System.Drawing.Point(12, 223);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(333, 70);
            this.panel1.TabIndex = 4;
            // 
            // lbl15
            // 
            this.lbl15.BackColor = System.Drawing.Color.White;
            this.lbl15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl15.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl15.ForeColor = System.Drawing.Color.Black;
            this.lbl15.Location = new System.Drawing.Point(267, 3);
            this.lbl15.Name = "lbl15";
            this.lbl15.Size = new System.Drawing.Size(60, 60);
            this.lbl15.TabIndex = 24;
            this.lbl15.Text = "E";
            this.lbl15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl14
            // 
            this.lbl14.BackColor = System.Drawing.Color.White;
            this.lbl14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl14.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl14.ForeColor = System.Drawing.Color.Black;
            this.lbl14.Location = new System.Drawing.Point(201, 3);
            this.lbl14.Name = "lbl14";
            this.lbl14.Size = new System.Drawing.Size(60, 60);
            this.lbl14.TabIndex = 23;
            this.lbl14.Text = "C";
            this.lbl14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl13
            // 
            this.lbl13.BackColor = System.Drawing.Color.White;
            this.lbl13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl13.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl13.ForeColor = System.Drawing.Color.Black;
            this.lbl13.Location = new System.Drawing.Point(135, 3);
            this.lbl13.Name = "lbl13";
            this.lbl13.Size = new System.Drawing.Size(60, 60);
            this.lbl13.TabIndex = 22;
            this.lbl13.Text = "N";
            this.lbl13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl12
            // 
            this.lbl12.BackColor = System.Drawing.Color.White;
            this.lbl12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl12.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl12.ForeColor = System.Drawing.Color.Black;
            this.lbl12.Location = new System.Drawing.Point(69, 3);
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(60, 60);
            this.lbl12.TabIndex = 21;
            this.lbl12.Text = "A";
            this.lbl12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl11
            // 
            this.lbl11.BackColor = System.Drawing.Color.White;
            this.lbl11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl11.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl11.ForeColor = System.Drawing.Color.Black;
            this.lbl11.Location = new System.Drawing.Point(3, 3);
            this.lbl11.Name = "lbl11";
            this.lbl11.Size = new System.Drawing.Size(60, 60);
            this.lbl11.TabIndex = 20;
            this.lbl11.Text = "D";
            this.lbl11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lbl25);
            this.panel2.Controls.Add(this.lbl24);
            this.panel2.Controls.Add(this.lbl23);
            this.panel2.Controls.Add(this.lbl22);
            this.panel2.Controls.Add(this.lbl21);
            this.panel2.Location = new System.Drawing.Point(12, 347);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(333, 70);
            this.panel2.TabIndex = 5;
            // 
            // lbl25
            // 
            this.lbl25.BackColor = System.Drawing.Color.White;
            this.lbl25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl25.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl25.ForeColor = System.Drawing.Color.Black;
            this.lbl25.Location = new System.Drawing.Point(267, 3);
            this.lbl25.Name = "lbl25";
            this.lbl25.Size = new System.Drawing.Size(60, 60);
            this.lbl25.TabIndex = 24;
            this.lbl25.Text = "S";
            this.lbl25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl24
            // 
            this.lbl24.BackColor = System.Drawing.Color.White;
            this.lbl24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl24.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl24.ForeColor = System.Drawing.Color.Black;
            this.lbl24.Location = new System.Drawing.Point(201, 3);
            this.lbl24.Name = "lbl24";
            this.lbl24.Size = new System.Drawing.Size(60, 60);
            this.lbl24.TabIndex = 23;
            this.lbl24.Text = "U";
            this.lbl24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl23
            // 
            this.lbl23.BackColor = System.Drawing.Color.White;
            this.lbl23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl23.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl23.ForeColor = System.Drawing.Color.Black;
            this.lbl23.Location = new System.Drawing.Point(135, 3);
            this.lbl23.Name = "lbl23";
            this.lbl23.Size = new System.Drawing.Size(60, 60);
            this.lbl23.TabIndex = 22;
            this.lbl23.Text = "N";
            this.lbl23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl22
            // 
            this.lbl22.BackColor = System.Drawing.Color.White;
            this.lbl22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl22.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl22.ForeColor = System.Drawing.Color.Black;
            this.lbl22.Location = new System.Drawing.Point(69, 3);
            this.lbl22.Name = "lbl22";
            this.lbl22.Size = new System.Drawing.Size(60, 60);
            this.lbl22.TabIndex = 21;
            this.lbl22.Text = "O";
            this.lbl22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl21
            // 
            this.lbl21.BackColor = System.Drawing.Color.White;
            this.lbl21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl21.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl21.ForeColor = System.Drawing.Color.Black;
            this.lbl21.Location = new System.Drawing.Point(3, 3);
            this.lbl21.Name = "lbl21";
            this.lbl21.Size = new System.Drawing.Size(60, 60);
            this.lbl21.TabIndex = 20;
            this.lbl21.Text = "B";
            this.lbl21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.lbl35);
            this.panel3.Controls.Add(this.lbl34);
            this.panel3.Controls.Add(this.lbl33);
            this.panel3.Controls.Add(this.lbl32);
            this.panel3.Controls.Add(this.lbl31);
            this.panel3.Location = new System.Drawing.Point(12, 475);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(333, 70);
            this.panel3.TabIndex = 6;
            // 
            // lbl35
            // 
            this.lbl35.BackColor = System.Drawing.Color.White;
            this.lbl35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl35.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl35.ForeColor = System.Drawing.Color.Black;
            this.lbl35.Location = new System.Drawing.Point(267, 3);
            this.lbl35.Name = "lbl35";
            this.lbl35.Size = new System.Drawing.Size(60, 60);
            this.lbl35.TabIndex = 24;
            this.lbl35.Text = "L";
            this.lbl35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl34
            // 
            this.lbl34.BackColor = System.Drawing.Color.White;
            this.lbl34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl34.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl34.ForeColor = System.Drawing.Color.Black;
            this.lbl34.Location = new System.Drawing.Point(201, 3);
            this.lbl34.Name = "lbl34";
            this.lbl34.Size = new System.Drawing.Size(60, 60);
            this.lbl34.TabIndex = 23;
            this.lbl34.Text = "A";
            this.lbl34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl33
            // 
            this.lbl33.BackColor = System.Drawing.Color.White;
            this.lbl33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl33.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl33.ForeColor = System.Drawing.Color.Black;
            this.lbl33.Location = new System.Drawing.Point(135, 3);
            this.lbl33.Name = "lbl33";
            this.lbl33.Size = new System.Drawing.Size(60, 60);
            this.lbl33.TabIndex = 22;
            this.lbl33.Text = "T";
            this.lbl33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl32
            // 
            this.lbl32.BackColor = System.Drawing.Color.White;
            this.lbl32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl32.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl32.ForeColor = System.Drawing.Color.Black;
            this.lbl32.Location = new System.Drawing.Point(69, 3);
            this.lbl32.Name = "lbl32";
            this.lbl32.Size = new System.Drawing.Size(60, 60);
            this.lbl32.TabIndex = 21;
            this.lbl32.Text = "O";
            this.lbl32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl31
            // 
            this.lbl31.BackColor = System.Drawing.Color.White;
            this.lbl31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl31.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl31.ForeColor = System.Drawing.Color.Black;
            this.lbl31.Location = new System.Drawing.Point(3, 3);
            this.lbl31.Name = "lbl31";
            this.lbl31.Size = new System.Drawing.Size(60, 60);
            this.lbl31.TabIndex = 20;
            this.lbl31.Text = "T";
            this.lbl31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(14, 298);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(394, 34);
            this.label4.TabIndex = 7;
            this.label4.Text = "The letter D  is in the word and in the correct spot.";
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(14, 420);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(394, 34);
            this.label5.TabIndex = 8;
            this.label5.Text = "The letter N  is in the word but in the wrong spot.";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(14, 548);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(394, 34);
            this.label6.TabIndex = 9;
            this.label6.Text = "The letter A is not in the word in any spot";
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(425, 592);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(113, 43);
            this.btnClose.TabIndex = 27;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // frmViewHelp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(543, 649);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmViewHelp";
            this.Text = "ViewHelp";
            this.Load += new System.EventHandler(this.frmViewHelp_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl15;
        private System.Windows.Forms.Label lbl14;
        private System.Windows.Forms.Label lbl13;
        private System.Windows.Forms.Label lbl12;
        private System.Windows.Forms.Label lbl11;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbl25;
        private System.Windows.Forms.Label lbl24;
        private System.Windows.Forms.Label lbl23;
        private System.Windows.Forms.Label lbl22;
        private System.Windows.Forms.Label lbl21;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lbl35;
        private System.Windows.Forms.Label lbl34;
        private System.Windows.Forms.Label lbl33;
        private System.Windows.Forms.Label lbl32;
        private System.Windows.Forms.Label lbl31;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnClose;
    }
}